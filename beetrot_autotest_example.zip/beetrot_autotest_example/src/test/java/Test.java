import org.apache.log4j.BasicConfigurator;

import static com.codeborne.selenide.Selenide.open;

public class Test {
    @org.junit.Test
    public void googleTest() {
        BasicConfigurator.configure();
        System.setProperty("webdriver.chrome.whitelistedIps", "");
        open("https://www.google.com.ua/");
    }
}
